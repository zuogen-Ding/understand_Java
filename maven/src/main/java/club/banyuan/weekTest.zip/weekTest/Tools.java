package club.banyuan.weekTest;

import java.util.ArrayList;
import java.util.List;

public class Tools {

    static List list=new ArrayList();

    static int count=0;
}
