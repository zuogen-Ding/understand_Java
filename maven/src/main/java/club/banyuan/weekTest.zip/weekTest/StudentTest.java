package club.banyuan.weekTest;

public class StudentTest {
    public static void main(String[] args) {
        StudentAdmin studentAdmin=new StudentAdmin();
    }
}
